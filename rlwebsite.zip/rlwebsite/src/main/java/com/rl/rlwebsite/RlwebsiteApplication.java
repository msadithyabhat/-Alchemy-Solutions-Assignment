package com.rl.rlwebsite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RlwebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(RlwebsiteApplication.class, args);
	}

}
