package com.rl.mywebsite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MywebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
