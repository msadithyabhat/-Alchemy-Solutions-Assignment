package Batch89;

import java.util.Scanner;

public class Calculator {
	public int rladd(int a,int b) {
		return a+b;
	}
	
	public int rlsub(int a,int b) {
		return a-b;
	}
	
	public int rlmul(int a,int b) {
		return a*b;
	}
	
	public int rldiv(int a,int b) {
		return a/b;
	}
	
	public void rlCalculator() {
		Scanner sc=new Scanner(System.in);
		int n;
		System.out.println("1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n");
		System.out.println("Enter your choice=");
		n=sc.nextInt();
		
		int a,b;
		
		System.out.println("Enter 1st value=");
		a=sc.nextInt();
		System.out.println("Enter 2nd value=");
		b=sc.nextInt();
	
		switch(n) {
		case 1:
			System.out.println("Addition is= "+ rladd(a,b));
			break;
		case 2: 
			System.out.println("Subtraction is="+rlsub(a,b));
			break;
		case 3: 
			System.out.println("Multiplication is="+rlmul(a,b));
			break;
		case 4: 
			System.out.println("Division is="+rldiv(a,b));
			break;
	default: System.out.println("Invalid Choice");
		}
	}
	
	
	
	public static void main(String[] args) {
		Calculator c=new Calculator();
		c.rlCalculator();
		
	}
}
