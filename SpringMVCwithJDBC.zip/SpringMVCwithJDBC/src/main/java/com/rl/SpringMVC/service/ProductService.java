package com.rl.SpringMVC.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rl.SpringMVC.dao.ProductDAO;
import com.rl.SpringMVC.model.Product;

@Service
public class ProductService {

	private HashMap<Integer, Product> productsDB;

	

		@Autowired
		private ProductDAO productsDAO;
	

		public void saveProduct(Product product) {

			productsDAO.addProduct(product);

		}

		public Product getProduct(int id) {

			return productsDAO.getProduct(id);

		}

		public List<Product> getAllProduct() {

			return productsDAO.getAllProduct();

		}

		public void deleteProduct(int id) {

			productsDAO.deleteProduct(id);

		}

		public void editProduct(Product product) {

			productsDAO.editProduct(product);

		}

	}
