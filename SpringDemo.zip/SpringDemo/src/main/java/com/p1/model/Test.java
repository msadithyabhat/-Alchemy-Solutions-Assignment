package com.p1.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.p1.Bike;
import com.p1.Car;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Car car=(Car) context.getBean("car");
		car.start();
		
		Bike bike=(Bike) context.getBean("bike");
		bike.start();
	}

}
