package soap.rl;

import java.util.Scanner;

public class p6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1st value=");
		int n1=sc.nextInt();
		System.out.println("Enter 2nd value=");
		int n2=sc.nextInt();
		System.out.println(n1+" + "+n2+" = "+(n1+n2));
		System.out.println(n1+" - "+n2+" = "+(n1-n2));
		System.out.println(n1+" x "+n2+" = "+(n1*n2));
		System.out.println(n1+" / "+n2+" = "+(n1/n2));
		System.out.println(n1+" mod "+n2+" = "+(n1%n2));
	}

}
