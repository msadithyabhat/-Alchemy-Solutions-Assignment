package soap.rl;

import java.util.Scanner;

public class p13 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input Width:");
		float n1=sc.nextFloat();
		System.out.println("Input height:");
		float n2=sc.nextFloat();
		
		float p=0,a=0;
		a=n1*n2;
		p=2*(n1+n2);
		System.out.println("Area is "+n1+" * "+n2+" = "+a);
		System.out.println("Perimeter is 2 * ("+n1+" + "+n2+") = "+a);
	}

}
