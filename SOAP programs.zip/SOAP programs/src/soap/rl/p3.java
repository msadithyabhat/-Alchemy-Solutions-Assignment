package soap.rl;

import java.util.Scanner;

public class p3 {
	public static void main(String[] args) {
		
		int a=50;
		int b=3;
		System.out.println(a/b);
	}

}
