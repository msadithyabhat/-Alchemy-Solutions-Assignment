package soap.rl;

import java.util.Scanner;

public class p8 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		        System.out.println("   J    a   v     v  a ");
		        System.out.println("   J   a a   v   v  a a");
		        System.out.println("J  J  aaaaa   V V  aaaaa");
		        System.out.println(" JJ  a     a   V  a     a");
		  
	}

}
