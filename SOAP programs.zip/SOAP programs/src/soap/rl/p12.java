package soap.rl;

import java.util.Scanner;

public class p12 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input first number:");
		int n1=sc.nextInt();
		System.out.println("Input second number:");
		int n2=sc.nextInt();
		System.out.println("Input third number:");
		int n3=sc.nextInt();
		int s=0;
		s=n1+n2+n3;
		int a= s/3;
		System.out.println("Average="+a);
	}

}
