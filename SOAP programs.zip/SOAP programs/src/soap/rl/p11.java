package soap.rl;

import java.util.Scanner;

public class p11 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input Radius =:");
		double r=sc.nextDouble();
		double p=0,a=0;
		p= (22*2*r)/7;
		a=(22*r*r)/7;
	
		System.out.println("Perimeter is ="+p);
		System.out.println("Area is ="+a);
		
	}

}
