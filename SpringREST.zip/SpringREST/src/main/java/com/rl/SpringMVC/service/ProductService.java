package com.rl.SpringMVC.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rl.SpringMVC.dao.ProductDAO;
import com.rl.SpringMVC.model.Product;
import com.rl.SpringMVC.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository productRepository;

	public Product saveProduct(Product product) {
		return productRepository.save(product);
	}

	public Product editProduct(Product product) {
		return productRepository.save(product);
	}

	public Optional<Product> getProduct(int id) {
		return productRepository.findById(id);
	}

	public List<Product> getAllProduct() {
		return productRepository.findAll();
	}

	public void deleteProduct(int id) {
		productRepository.deleteById(id);
	}

}