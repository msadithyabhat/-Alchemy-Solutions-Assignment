package Batch89;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
	@BeforeClass
	public static void testBefore() {
		Calculator c1=new Calculator();
		assertEquals(c1.rladd(2, 4), 6);
	}
	
	@Test
	public void testAddition() {
		Calculator c1=new Calculator();
		assertEquals(c1.rladd(2, 4), 6);
	}
	@Test
	public void testSubtraction() {
		Calculator c1=new Calculator();
		assertEquals(c1.rlsub(2, 4), -2);
	}
	@Test
	public void testMultiplication() {
		Calculator c1=new Calculator();
		assertEquals(c1.rlmul(2, 4), 8);
	}
	@Test
	public void testDivision() {
		Calculator c1=new Calculator();
		assertEquals(c1.rldiv(6, 3), 2);
	}
	@Test(expected = ArithmeticException.class)
	public void testDivision1() {
		Calculator c1=new Calculator();
		assertEquals(c1.rldiv(6, 0), 0);
	}
	@AfterClass
	public static void testAfter() {
		Calculator c1=new Calculator();
		assertEquals(c1.rladd(2, 4), 6);
	}
	

}
