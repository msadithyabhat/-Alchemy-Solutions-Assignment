package com.p1;

import org.springframework.stereotype.Component;

@Component
public class Tyre {

}
