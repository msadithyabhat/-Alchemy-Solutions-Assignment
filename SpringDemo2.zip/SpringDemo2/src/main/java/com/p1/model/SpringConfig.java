package com.p1.model;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.p1.Bike;
import com.p1.Car;
import com.p1.Engine;

@Configuration
@ComponentScan(basePackages="com.p1")

public class SpringConfig {
	
	@Bean
	public Engine getEngine() {
		return new Engine("3000 CC");


}
}
