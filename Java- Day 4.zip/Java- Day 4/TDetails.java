
public class TDetails {
	private int TID;
	private String TName;
	private String TSub;
	private int TClass;
	
	public TDetails() {
		this.TID=0;
		this.TName=null;
		this.TSub=null;
		this.TClass=0;
	}
	public TDetails(int tid,String tname,String tsub,int tclass) {
		this.TID=tid;
		this.TName=tname;
		this.TSub=tsub;
		this.TClass=tclass;
	}
	public int getTID() {
		return TID;
	}
	public void setTID(int tID) {
		TID = tID;
	}
	public String getTName() {
		return TName;
	}
	public void setTName(String tName) {
		TName = tName;
	}
	public String getTSub() {
		return TSub;
	}
	public void setTSub(String tSub) {
		TSub = tSub;
	}
	public int getTClass() {
		return TClass;
	}
	public void setTClass(int tClass) {
		TClass = tClass;
	}
	@Override
	public String toString() {
		return "TDetails [TID=" + TID + ", TName=" + TName + ", TSub=" + TSub + ", TClass=" + TClass + "]";
	}
	
}
