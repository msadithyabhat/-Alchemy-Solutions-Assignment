import java.util.ArrayList;
import java.util.Scanner;

public class Main {
AllDetails ad=new AllDetails();
Scanner sc=new Scanner(System.in);

private void sadd() {
	int sclass,sage;
	String sname,semail,fstatus;
	
	System.out.println("Enter the Student Name=");
	sname=sc.next();
	System.out.println("Enter the Student Class=");
	sclass=sc.nextInt();
	System.out.println("Enter the Student Email=");
	semail=sc.next();
	System.out.println("Enter the Student Age=");
	sage=sc.nextInt();
	System.out.println("Enter the Student Fee Status=");
	fstatus=sc.next();
	System.out.println("Student Data is added");
	
	 int rollno = ad.lastStudentID() + 1;

     SDetails sd = new SDetails(rollno, sname, sclass, semail, sage,fstatus);
     ad.add(sd);
}
private void tadd() {
	int tid,tclass;
	String tsub,tname;
	System.out.println("Enter the Teacher Name=");
	tname=sc.next();
	System.out.println("Enter the Teacher Subject=");
	tsub=sc.next();
	System.out.println("Enter the Teacher Class=");
	tclass=sc.nextInt();
	System.out.println("Teacher Data is added");
	
	tid = ad.lastTeacherID() + 1;

    TDetails td = new TDetails(tid, tname, tsub, tclass);
    ad.add(td);
}
private void allStudents() {
	ad.printAllStudents();
}
private void allTeachers() {
	ad.printAllTeachers();
}
private void allFeeDetails() {
	System.out.println("1. Details of Fee Paid\n2. Details of Fee Pending");
	int f=sc.nextInt();
	switch(f) {
	case 1:
		this.fpaid();
		break;
	case 2:
		this.fpending();
		break;
	default:
		System.out.println("Invalid Input\n");
		break;
	}
}
private void supdate() {
	int rollno,sclass,sage;
	String sname,semail,fstatus;
	System.out.println("Update Student RollNo=");
	rollno=sc.nextInt();
	System.out.println("Update Student Name=");
	sname=sc.next();
	System.out.println("Update Student Class=");
	sclass=sc.nextInt();
	System.out.println("Update Student Email=");
	semail=sc.next();
	System.out.println("Update Student Age=");
	sage=sc.nextInt();
	System.out.println("Update Student Fee Status=");
	fstatus=sc.next();
	
	SDetails sd = new SDetails(rollno, sname, sclass, semail, sage,fstatus);
	boolean status=ad.updateIfStudent(sd, rollno);
	if(status==true)
		System.out.println("Student Data is Updated");
	else
		System.out.println("Student Data is not Updated");
}

private void tupdate() {
	int tid,tclass;
	String tsub,tname;
	System.out.println("Enter the Teacher ID=");
	tid=sc.nextInt();
	System.out.println("Enter the Teacher Name=");
	tname=sc.next();
	System.out.println("Enter the Teacher Subject=");
	tsub=sc.next();
	System.out.println("Enter the Teacher Class=");
	tclass=sc.nextInt();
	
	TDetails td = new TDetails(tid, tname, tsub, tclass);
	boolean status=ad.updateIfTeacher(td, tid);
	if(status==true)
		System.out.println("Teacher Data is Updated");
	else
		System.out.println("Teacher Data is not Updated");
}

private void fpending() {
	ad.feePending();
}
private void fpaid() {
   ad.feePaid();
}
    
private void ssearch() {
    int rollno;
    System.out.print("Enter Roll No of Student which you want to Search:\n");
    rollno = sc.nextInt();
    ad.searchRStudent(rollno);
}

private void tsearch() {
    int tid;
    System.out.print("Enter ID of Teacher which you want to Search:");
    tid = sc.nextInt();
    ad.searchRTeacher(tid);
}


private void searchSName() {
    String sname;
    System.out.println("Enter Student Name which you want to Search:   ");
    sname = sc.next();
    System.out.println(sname);
    ArrayList<SDetails> sbs = ad.searchStudent(sname);
    if (sbs.size()==0) {
        System.out.println("Invalid Search Name");
    }else {
        for(SDetails s : sbs)
            System.out.println(s);
    }
}

private void searchTName() {
    String tname;
    System.out.println("Enter Teacher Name which you want to Search:   ");
    tname = sc.next();
    System.out.println(tname);
    ArrayList<TDetails> sbs = ad.searchTeacher(tname);
    if (sbs.size()==0) {
        System.out.println("Invalid Search Name");
    }else {
        for(TDetails t : sbs)
            System.out.println(t);
    }
}

private void searchingS() {
	System.out.println("1. Search by ID\n2.Search by Name");
	int n=sc.nextInt();
	switch(n) {
	case 1:
		this.ssearch();
		break;
	case 2:
		this.searchSName();
		break;
	default:
		System.out.println("Invalid Search\n");
	}
}

private void searchingT() {
	System.out.println("1. Search by ID\n2.Search by Name");
	int n1=sc.nextInt();
	switch(n1) {
	case 1:
		this.tsearch();
		break;
	case 2:
		this.searchTName();
		break;
	default:
		System.out.println("Invalid Search\n");
	}
}
    
    public void initial() {
      
                while(true) {
                	System.out.println("\nWelcome to RSSN School Management\n");
                    System.out.println("1. List all the Students");
                    System.out.println("2. List all the Teachers");
                    System.out.println("3. Add a Student");
                    System.out.println("4. Add a Teacher");
                    System.out.println("5. Search Student");
                    System.out.println("6. Search Teacher");
                    System.out.println("7. Update Student");
                    System.out.println("8. Update Teacher");
                    System.out.println("9. Fee Status");
                    System.out.println("10. Exit");
                    System.out.println("Enter your choice=");
                    int ch = sc.nextInt();
                    switch(ch) {
                    case 1:
                        this.allStudents();
                        break;
                    case 2:
                        this.allTeachers();
                        break;
                    case 3:
                    	this.sadd();
                        break;
                    case 4:
                        this.tadd();
                        break;
                    case 5:
                    	this.searchingS();
                        break;
                    case 6:
                        this.searchingT();
                        break;
                    case 7:
                        this.supdate();
                        break;
                    case 8:
                        this.tupdate();
                        break;
                    case 9:
                    	this.allFeeDetails();
                    	break;
                    case 10:
                    	System.out.println("Bye...!!!");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid Entry");
                    }

                }
            }
            
    
public static void main(String[] args) {
    	Main m=new Main();
    	m.initial();
    }
    	
    }
        


