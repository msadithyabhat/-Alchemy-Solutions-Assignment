
public class SDetails {
private int Rollno;
private String SName;
private int SClass;
private String SEmail;
private int SAge;
private String FStatus;

public SDetails() {
	this.Rollno=0;
	this.SName=null;
	this.SClass=0;
	this.SEmail=null;
	this.SAge=0;
	this.FStatus=null;
	
}
public SDetails(int rollno,String sname,int sclass,String semail,int sage,String fstatus) {
	this.Rollno=rollno;
	this.SName=sname;
	this.SClass=sclass;
	this.SEmail=semail;
	this.SAge=sage;	
	this.FStatus=fstatus;
}
public int getRollno() {
	return Rollno;
}
public void setRollno(int rollno) {
	Rollno = rollno;
}
public String getSName() {
	return SName;
}
public void setSName(String sName) {
	SName = sName;
}
public int getSClass() {
	return SClass;
}
public void setSClass(int sClass) {
	SClass = sClass;
}
public String getSEmail() {
	return SEmail;
}
public void setSEmail(String sEmail) {
	SEmail = sEmail;
}
public int getSAge() {
	return SAge;
}
public void setSAge(int sAge) {
	SAge = sAge;
}
public String getFStatus() {
	return FStatus;
}
public void setFStatus(String fStatus) {
	FStatus = fStatus;
}
@Override
public String toString() {
	return "SDetails [Rollno=" + Rollno + ", SName=" + SName + ", SClass=" + SClass + ", SEmail=" + SEmail + ", SAge="
			+ SAge + ", FStatus=" + FStatus + "]";
}

}
