import java.util.ArrayList;


public class AllDetails {
private ArrayList<SDetails> sd= new ArrayList<>();
private ArrayList<TDetails> td= new ArrayList<>();

public AllDetails() {
	
}
public AllDetails(SDetails sdetails) {
	sd.add(sdetails);
}
public AllDetails(TDetails tdetails) {
	td.add(tdetails);
}
public void add(SDetails sdd) {
	sd.add(sdd);
}
public void add(TDetails tdd) {
	td.add(tdd);
}

public ArrayList<SDetails> searchStudent(String sname) {
    ArrayList<SDetails> sD = new ArrayList<>();
    for(SDetails s : sd) {
        if(s.getSName().equals(sname)) {
            sD.add(s);
        }
    }
    return sD;
}

public ArrayList<TDetails> searchTeacher(String tname) {
    ArrayList<TDetails> tD = new ArrayList<>();
    for(TDetails t : td) {
        if(t.getTName().equals(tname)) {
            tD.add(t);
        }
    }
    return tD;
}

public SDetails searchRStudent(int rollno) {
	for(SDetails s : sd) {
		if(s.getRollno()==rollno) {
			System.out.println(s);
		}
		else {
			System.out.println("Data not Found\n");
	}
		}
	return null;
}

public TDetails searchRTeacher(int tid) {
	for(TDetails t : td) {
		if(t.getTID()== tid) {
			System.out.println(t);
		}
		else
			System.out.println("Data not Found\n");
	}
	return null;
}

public void feePending() {
	String p2="Pending";
	for(SDetails s : sd) {
		
		if(s.getFStatus().equals(p2)) 
			System.out.println(s);
		else
			System.out.println("Data not Found\n");
	}
}

public void feePaid(){
	String p2="Paid";
	for(SDetails s : sd) {
		if(s.getFStatus().equals(p2)) 
			System.out.println(s);
		else
			System.out.println("Data not Found\n");
	}
}

public void printAllStudents() {
	
		if(sd.isEmpty()==true) {
			System.out.println("Data not found");
		}
		else {
			for(SDetails s : sd) {
				System.out.println(s);
		}
		}
}

public void printAllTeachers() {
	if(sd.isEmpty()==true) {
		System.out.println("Data not found");
	}
	else {
	for(TDetails t : td) {
			System.out.println(t);
	}}
}

public boolean updateIfStudent(SDetails us, int rollno) {
	boolean supdate=false;
	for(SDetails s: sd) {
		if(s.getRollno()==rollno) {
			s.setRollno(us.getRollno());
			s.setSName(us.getSName());
			s.setSClass(us.getSClass());
			s.setSEmail(us.getSEmail());
			s.setSAge(us.getSAge());
			s.setFStatus(us.getFStatus());
			supdate=true;
		}
	}
	return supdate;
}

public boolean updateIfTeacher(TDetails ut, int tid) {
	boolean tupdate=false;
	for(TDetails t: td) {
		if(t.getTID()==tid) {
			t.setTID(ut.getTID());
			t.setTName(ut.getTName());
			t.setTSub(ut.getTSub());
			t.setTClass(ut.getTClass());
			tupdate=true;
		}
	}
	return tupdate;
}

public void updateStudent(SDetails us, int rollno) {
	boolean supdate=false;
	for(SDetails s: sd) {
		if(s.getRollno()==rollno) {
			s.setRollno(us.getRollno());
			s.setSName(us.getSName());
			s.setSClass(us.getSClass());
			s.setSEmail(us.getSEmail());
			s.setSAge(us.getSAge());
			s.setFStatus(us.getFStatus());
			supdate=true;
		}
	}
	if(supdate==false) {
		sd.add(us);
	}
}

public void updateTeacher(TDetails ut, int tid) {
	boolean tupdate=false;
	for(TDetails t: td) {
		if(t.getTID()==tid) {
			t.setTID(ut.getTID());
			t.setTName(ut.getTName());
			t.setTSub(ut.getTSub());
			t.setTClass(ut.getTClass());
			tupdate=true;
		}
	}
	if(tupdate==false) {
		td.add(ut);
	}
}

public int ssize() {
    return sd.size();
}

public int tsize() {
    return td.size();
}

public int lastStudentID() {
    int LastSID=0;
    for(SDetails s: sd) {
        LastSID = s.getRollno();
    }
    return LastSID;
}


public int lastTeacherID() {
    int LastTID=0;
    for(TDetails t: td) {
        LastTID = t.getTID();
    }
    return LastTID;
}



}

